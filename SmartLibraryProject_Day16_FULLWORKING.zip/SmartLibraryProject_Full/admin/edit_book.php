<?php
include '../includes/admin_header.php';
include '../backend/db.php';
if(!isset($_GET['id'])){die('No book ID');}
$id=$_GET['id'];
$stmt=$conn->prepare("SELECT * FROM book WHERE book_id=?");
$stmt->bind_param("i",$id);$stmt->execute();$res=$stmt->get_result();$book=$res->fetch_assoc();
$stmt->close();$conn->close();
?>
<h2 class="mb-4">Edit Book</h2>
<form action="../backend/update_book.php" method="POST" class="border p-4 bg-white rounded shadow-sm needs-validation" novalidate>
  <input type="hidden" name="book_id" value="<?=$book['book_id']?>">
  <div class="mb-3"><label>Title</label><input type="text" name="title" class="form-control" required value="<?=htmlspecialchars($book['title'])?>"></div>
  <div class="mb-3"><label>Author</label><input type="text" name="author" class="form-control" required value="<?=htmlspecialchars($book['author'])?>"></div>
  <div class="mb-3"><label>ISBN</label><input type="text" name="isbn" class="form-control" required pattern="^[0-9A-Za-z-]+$" value="<?=htmlspecialchars($book['isbn'])?>"></div>
  <div class="mb-3"><label>Category</label><input type="text" name="category" class="form-control" value="<?=htmlspecialchars($book['category'])?>"></div>
  <div class="mb-3"><label>Quantity</label><input type="number" min="0" name="quantity" class="form-control" required value="<?=$book['quantity']?>"></div>
  <button type="submit" class="btn btn-success">Save Changes</button>
  <a href="view_books.php" class="btn btn-secondary">Cancel</a>
</form>
<script>
(()=>{const f=document.querySelector('.needs-validation');f.addEventListener('submit',e=>{if(!f.checkValidity()){e.preventDefault();e.stopPropagation();}f.classList.add('was-validated');});})();</script>
<?php include '../includes/footer.php'; ?>
