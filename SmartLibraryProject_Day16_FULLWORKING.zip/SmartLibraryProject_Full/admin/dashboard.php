<?php
include '../includes/admin_header.php';
include '../backend/db.php';

/* Quick stats */
$totalBooks = $conn->query("SELECT COUNT(*) AS c FROM book WHERE is_deleted = FALSE")->fetch_assoc()['c'];
$totalAvail = $conn->query("SELECT COUNT(*) AS c FROM book WHERE is_deleted = FALSE AND quantity>0")->fetch_assoc()['c'];
$totalReq   = $conn->query("SELECT COUNT(*) AS c FROM book_requests")->fetch_assoc()['c'];
$pendingReq = $conn->query("SELECT COUNT(*) AS c FROM book_requests WHERE status='Pending'")->fetch_assoc()['c'];

/* Books per Category */
$catRes = $conn->query("SELECT COALESCE(NULLIF(category,''),'Uncategorized') AS cat, COUNT(*) AS c FROM book WHERE is_deleted = FALSE GROUP BY cat ORDER BY c DESC");
$categories = []; $catCounts = [];
while($r = $catRes->fetch_assoc()){ $categories[] = $r['cat']; $catCounts[] = (int)$r['c'];}

/* Requests per Status */
$statRes = $conn->query("SELECT status, COUNT(*) AS c FROM book_requests GROUP BY status");
$statuses=[];$statusCounts=[];
while($s=$statRes->fetch_assoc()){ $statuses[]=$s['status'];$statusCounts[]=(int)$s['c'];}

$conn->close();
?>
<h2>Welcome, Admin!</h2>
<p class="lead">Library overview.</p>

<div class="row g-3 mt-4">
  <div class="col-sm-6 col-lg-3">
    <div class="card text-bg-primary"><div class="card-body">
      <h5 class="card-title">Total Books</h5><p class="fs-3 fw-bold card-text"><?=$totalBooks?></p>
    </div></div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card text-bg-success"><div class="card-body">
      <h5 class="card-title">In Stock</h5><p class="fs-3 fw-bold card-text"><?=$totalAvail?></p>
    </div></div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card text-bg-warning"><div class="card-body">
      <h5 class="card-title">Total Requests</h5><p class="fs-3 fw-bold card-text"><?=$totalReq?></p>
    </div></div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card text-bg-danger"><div class="card-body">
      <h5 class="card-title">Pending</h5><p class="fs-3 fw-bold card-text"><?=$pendingReq?></p>
    </div></div>
  </div>
</div>

<hr class="my-5">

<div class="row g-5">
  <div class="col-md-6">
    <h4>Books per Category</h4>
    <canvas id="catChart" height="200"></canvas>
  </div>
  <div class="col-md-6">
    <h4>Requests by Status</h4>
    <canvas id="reqChart" height="200"></canvas>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const catData = {
  labels: <?=json_encode($categories)?>,
  datasets:[{label:'Books',data:<?=json_encode($catCounts)?>,backgroundColor:'rgba(54,162,235,0.5)',borderColor:'rgba(54,162,235,1)',borderWidth:1}]
};
const reqData = {
  labels: <?=json_encode($statuses)?>,
  datasets:[{label:'Requests',data:<?=json_encode($statusCounts)?>,backgroundColor:['rgba(255,206,86,0.5)','rgba(75,192,192,0.5)','rgba(255,99,132,0.5)'],borderWidth:1}]
};
new Chart(document.getElementById('catChart'),{type:'bar',data:catData});
new Chart(document.getElementById('reqChart'),{type:'pie',data:reqData});
</script>

<div class="mt-5 d-flex gap-2 flex-wrap">
  <a href="add_book.php" class="btn btn-primary btn-lg">Add Book</a>
  <a href="view_books.php" class="btn btn-secondary btn-lg">Manage Books</a>
  <a href="view_requests.php" class="btn btn-warning btn-lg text-white">Manage Requests</a>
</div>
<?php include '../includes/footer.php'; ?>
