<?php
include '../includes/client_header.php';
include '../backend/db.php';
if(!isset($_GET['book_id'])){die('No book ID');}
$book_id=$_GET['book_id'];
?>
<h2>Request Book</h2>
<form action="../backend/handle_request.php" method="POST" class="border p-4 bg-white shadow-sm rounded">
  <input type="hidden" name="book_id" value="<?=$book_id?>">
  <div class="mb-3">
    <label>Your Name</label>
    <input type="text" name="student_name" class="form-control" required value="<?=htmlspecialchars($_SESSION['student_name']);?>">
  </div>
  <div class="mb-3">
    <label>Student ID</label>
    <input type="text" name="student_id" class="form-control" required value="<?=htmlspecialchars($_SESSION['student_id']);?>">
  </div>
  <button type="submit" class="btn btn-primary">Submit Request</button>
  <a href="view_books.php" class="btn btn-secondary">Back</a>
</form>
<?php include '../includes/footer.php'; ?>
