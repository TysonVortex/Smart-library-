<?php
include '../includes/client_header.php';
include '../backend/db.php';

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$available = isset($_GET['available']) ? true : false;

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$where = "is_deleted = FALSE";
$params = [];
$types = "";

if ($search !== '') {
    $where .= " AND (title LIKE ? OR author LIKE ? OR isbn LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types .= "sss";
}
if ($category !== '') {
    $where .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}
if ($available) {
    $where .= " AND quantity > 0";
}

$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM book WHERE $where LIMIT ?, ?";
$params[] = $offset; 
$params[] = $limit;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$totalRes = $conn->query("SELECT FOUND_ROWS() AS total")->fetch_assoc();
$total = (int)$totalRes['total'];
$totalPages = max(1, (int)ceil($total/$limit));
?>
<h2 class="mb-4">Available Books</h2>

<form method="GET" class="mb-3 row g-2 align-items-end">
  <div class="col-md-4">
    <label class="form-label">Search</label>
    <input type="text" name="search" placeholder="Title, Author, ISBN" value="<?= htmlspecialchars($search) ?>" class="form-control" />
  </div>
  <div class="col-md-3">
    <label class="form-label">Category</label>
    <input list="catlist" name="category" value="<?= htmlspecialchars($category) ?>" class="form-control" placeholder="All">
    <datalist id="catlist">
      <option value="Science">
      <option value="Math">
      <option value="Literature">
      <option value="Technology">
    </datalist>
  </div>
  <div class="col-md-2">
    <div class="form-check mt-4">
      <input class="form-check-input" type="checkbox" name="available" value="1" <?= $available?'checked':'' ?>>
      <label class="form-check-label">Available Only</label>
    </div>
  </div>
  <div class="col-md-3">
    <button type="submit" class="btn btn-secondary w-100"><i class="bi bi-funnel"></i> Filter</button>
  </div>
</form>

<div class="table-responsive">
<table class="table table-bordered table-striped align-middle">
  <thead class="table-dark">
    <tr>
      <th>Title</th>
      <th>Author</th>
      <th>ISBN</th>
      <th>Category</th>
      <th>Quantity</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr class="<?= $row['quantity']==0 ? 'table-danger' : '' ?>">
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><?= htmlspecialchars($row['author']) ?></td>
          <td><?= htmlspecialchars($row['isbn']) ?></td>
          <td><?= htmlspecialchars($row['category']) ?></td>
          <td>
            <?= $row['quantity'] ?>
            <?php if ($row['quantity']==0): ?><span class="badge bg-danger ms-1">Out</span><?php endif; ?>
          </td>
          <td>
            <?php if ($row['quantity']>0): ?>
              <a href="request_book.php?book_id=<?= $row['book_id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-bag-plus"></i> Request</a>
            <?php else: ?>
              <button class="btn btn-sm btn-secondary" disabled><i class="bi bi-x-circle"></i> Unavailable</button>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="6" class="text-center">No books found.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</div>

<nav aria-label="Book pages">
  <ul class="pagination">
    <?php for($i=1;$i<=$totalPages;$i++): ?>
      <li class="page-item <?= ($i==$page)?'active':'' ?>">
        <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&category=<?= urlencode($category) ?>&available=<?= $available?1:'' ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>

<?php
$stmt->close();
$conn->close();
?>
<?php include '../includes/footer.php'; ?>
