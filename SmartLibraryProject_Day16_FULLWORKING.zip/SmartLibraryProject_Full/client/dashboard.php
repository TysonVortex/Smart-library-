<?php include '../includes/client_header.php'; ?>
<h2>Welcome, <?=htmlspecialchars($_SESSION['student_name']);?>!</h2>
<p class="lead">Browse books and track your requests.</p>
<div class="d-flex gap-2 flex-wrap mt-4">
  <a href="view_books.php" class="btn btn-primary btn-lg">Browse Books</a>
  <a href="my_requests.php" class="btn btn-secondary btn-lg">My Requests</a>
</div>
<?php include '../includes/footer.php'; ?>
