<?php
session_start();
if(isset($_SESSION['student_id'])){header("Location: dashboard.php");exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
  $_SESSION['student_name']=$_POST['student_name'];
  $_SESSION['student_id']=$_POST['student_id'];
  header("Location: dashboard.php");exit;
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Student Login</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"></head>
<body class="bg-light p-5"><div class="container">
<h2 class="mb-4">Student Login</h2>
<form method="POST" class="border p-4 bg-white rounded shadow-sm">
<div class="mb-3"><label>Your Name</label><input type="text" name="student_name" class="form-control" required autofocus></div>
<div class="mb-3"><label>Student ID</label><input type="text" name="student_id" class="form-control" required></div>
<button class="btn btn-primary" type="submit">Login</button>
</form>
<div class="mt-3"><a href="../index.php">&larr; Back</a></div>
</div></body></html>
