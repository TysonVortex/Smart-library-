<?php
/* Minimal FPDF stub.
 * Download the full library from http://www.fpdf.org/ and replace this file
 * for proper PDF generation.
 */
class FPDF {
    function AddPage() {}
    function SetFont($f,$s='',$z=12) {}
    function Cell($w,$h=0,$txt='',$b=0,$ln=0,$a='',$f2=false,$l=''){ echo $txt."\t"; }
    function Ln($h=null){ echo "\n"; }
    function Output(){}
}
?>
