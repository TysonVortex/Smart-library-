<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if(isset($_GET['id'],$_GET['action'])){
  $id=$_GET['id'];$act=$_GET['action'];
  $new_status=($act==='approve')?'Approved':(($act==='reject')?'Rejected':null);
  if($new_status){
    $stmt=$conn->prepare("UPDATE book_requests SET status=? WHERE request_id=?");
    $stmt->bind_param("si",$new_status,$id);
    if($stmt->execute()){set_flash('success','Request updated.');}
    else{set_flash('danger','Update error: '.$stmt->error);}
    $stmt->close();
  }
  $conn->close();
  header("Location: ../admin/view_requests.php");exit;
}else{echo 'Missing params';}
?>
