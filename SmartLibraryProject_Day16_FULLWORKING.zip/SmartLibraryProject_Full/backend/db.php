<?php
$host='localhost';$user='root';$password='';$db='smart_library';
$conn=new mysqli($host,$user,$password,$db);
if($conn->connect_error){die("DB Connection failed: ".$conn->connect_error);}
?>
