<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if(isset($_GET['id'])){
  $id=$_GET['id'];
  $stmt=$conn->prepare("UPDATE book SET is_deleted=TRUE WHERE book_id=?");
  $stmt->bind_param("i",$id);
  if($stmt->execute()){set_flash('success','Book deleted.');}
  else{set_flash('danger','Delete error: '.$stmt->error);}
  $stmt->close();$conn->close();
  header("Location: ../admin/view_books.php");exit;
}else{echo "No ID.";}
?>
