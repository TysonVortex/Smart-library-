<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $student_name=$_POST['student_name'];$student_id=$_POST['student_id'];$book_id=$_POST['book_id'];
  $stmt=$conn->prepare("INSERT INTO book_requests (student_name,student_id,book_id) VALUES (?,?,?)");
  $stmt->bind_param("ssi",$student_name,$student_id,$book_id);
  if($stmt->execute()){set_flash('success','Request submitted.');}
  else{set_flash('danger','Request error: '.$stmt->error);}
  $stmt->close();$conn->close();
  header("Location: ../client/view_books.php");exit;
}
?>
