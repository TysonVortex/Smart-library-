<?php
include 'db.php';

$format = $_GET['format'] ?? 'csv';
$sql = "SELECT title, author, isbn, category, quantity FROM book WHERE is_deleted = FALSE";
$result = $conn->query($sql);

if ($format === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="books.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Title','Author','ISBN','Category','Quantity']);
    while($row = $result->fetch_assoc()){fputcsv($output,$row);}
    fclose($output);
} elseif ($format === 'pdf') {
    require('../libs/fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10,'Book List',0,1,'C');
    $pdf->Ln(5);
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(60,10,'Title');$pdf->Cell(40,10,'Author');$pdf->Cell(30,10,'ISBN');$pdf->Cell(30,10,'Category');$pdf->Cell(15,10,'Qty');$pdf->Ln();
    $pdf->SetFont('Arial','',10);
    mysqli_data_seek($result,0);
    while($row=$result->fetch_assoc()){
      $pdf->Cell(60,8,substr($row['title'],0,30));
      $pdf->Cell(40,8,substr($row['author'],0,20));
      $pdf->Cell(30,8,$row['isbn']);
      $pdf->Cell(30,8,$row['category']);
      $pdf->Cell(15,8,$row['quantity']);$pdf->Ln();
    }
    $pdf->Output();
} else {
    echo 'Invalid format';
}
$conn->close();
?>
