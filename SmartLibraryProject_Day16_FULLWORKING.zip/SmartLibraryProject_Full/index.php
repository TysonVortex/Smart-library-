<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Smart Library - Welcome</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light p-5">
<div class="container text-center mt-5">
  <h1 class="mb-4">Smart Library Book Management System</h1>
  <p class="mb-4">Select your portal:</p>
  <a href="admin/login.php" class="btn btn-dark btn-lg me-3">Admin Portal</a>
  <a href="client/login.php" class="btn btn-primary btn-lg">Student Portal</a>
</div>
</body>
</html>
