<?php
session_start(); 
if(!isset($_SESSION['student_id'])){header("Location: ../client/login.php");exit;}
require_once __DIR__.'/flash.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Student - Smart Library</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-primary bg-primary mb-4" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="../client/dashboard.php">Smart Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#clientNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="clientNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="../client/dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="../client/view_books.php">Browse Books</a></li>
        <li class="nav-item"><a class="nav-link" href="../client/my_requests.php">My Requests</a></li>
      </ul>
      <span class="navbar-text me-3"><?php echo htmlspecialchars($_SESSION['student_name']); ?></span>
      <a href="../client/logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
  </div>
</nav>
<div class="container mb-5">
<?php show_flash(); ?>
