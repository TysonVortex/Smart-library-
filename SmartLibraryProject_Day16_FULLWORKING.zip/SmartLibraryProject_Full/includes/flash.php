<?php
if (session_status() === PHP_SESSION_NONE) session_start();
function set_flash($t,$m){ $_SESSION['flash']=['type'=>$t,'msg'=>$m]; }
function show_flash(){
 if(!empty($_SESSION['flash'])){
   $t=htmlspecialchars($_SESSION['flash']['type']);
   $m=htmlspecialchars($_SESSION['flash']['msg']);
   echo "<div class='alert alert-$t alert-dismissible fade show' role='alert'>$m<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
   unset($_SESSION['flash']);
 }
}
?>
