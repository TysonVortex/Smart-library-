<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book_id  = $_POST['book_id'];
    $title    = $_POST['title'];
    $author   = $_POST['author'];
    $isbn     = $_POST['isbn'];
    $category = $_POST['category'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("UPDATE book SET title=?, author=?, isbn=?, category=?, quantity=? WHERE book_id=?");
    $stmt->bind_param("ssssii", $title, $author, $isbn, $category, $quantity, $book_id);

    if ($stmt->execute()) {
        set_flash('success', 'Book updated successfully.');
        header("Location: ../admin/view_books.php");
    } else {
        set_flash('danger', 'Error updating book: ' . $stmt->error);
        header("Location: ../admin/edit_book.php?id=" . $book_id);
    }
    $stmt->close();
    $conn->close();
    exit;
}
?>
