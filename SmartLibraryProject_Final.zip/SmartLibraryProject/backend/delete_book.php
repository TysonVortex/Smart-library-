<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("UPDATE book SET is_deleted = TRUE WHERE book_id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        set_flash('success', 'Book deleted.');
        header("Location: ../admin/view_books.php");
    } else {
        set_flash('danger', 'Error deleting book: ' . $stmt->error);
        header("Location: ../admin/view_books.php");
    }
    $stmt->close();
    $conn->close();
    exit;
} else {
    echo "No book ID provided.";
}
?>
