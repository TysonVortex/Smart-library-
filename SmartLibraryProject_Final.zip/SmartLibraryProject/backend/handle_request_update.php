<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if (isset($_GET['id']) && isset($_GET['action'])) {
    $request_id = $_GET['id'];
    $action = $_GET['action'];

    if ($action === 'approve' || $action === 'reject') {
        $new_status = $action === 'approve' ? 'Approved' : 'Rejected';

        $stmt = $conn->prepare("UPDATE book_requests SET status = ? WHERE request_id = ?");
        $stmt->bind_param("si", $new_status, $request_id);

        if ($stmt->execute()) {
            set_flash('success', 'Request status updated.');
            header("Location: ../admin/view_requests.php");
        } else {
            set_flash('danger', 'Error updating request: ' . $stmt->error);
            header("Location: ../admin/view_requests.php");
        }
        $stmt->close();
        $conn->close();
        exit;
    } else {
        echo "Invalid action.";
    }
} else {
    echo "Missing parameters.";
}
?>
