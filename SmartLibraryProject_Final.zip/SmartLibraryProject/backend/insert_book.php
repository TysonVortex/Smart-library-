<?php
session_start();
include 'db.php';
require_once '../includes/flash.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title    = $_POST['title'];
    $author   = $_POST['author'];
    $isbn     = $_POST['isbn'];
    $category = $_POST['category'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("INSERT INTO book (title, author, isbn, category, quantity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $title, $author, $isbn, $category, $quantity);

    if ($stmt->execute()) {
        set_flash('success', 'Book added successfully!');
        header("Location: ../admin/view_books.php");
    } else {
        set_flash('danger', 'Error adding book: ' . $stmt->error);
        header("Location: ../admin/add_book.php");
    }
    $stmt->close();
    $conn->close();
    exit;
}
?>
