<?php
// /backend/db.php
// Adjust credentials for your local environment.
$host = 'localhost';
$user = 'root';        // default for XAMPP/WAMP
$password = '';        // set if you have one
$db = 'smart_library';

$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}
?>
