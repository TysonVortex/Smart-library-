<?php
// /includes/admin_header.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin/login.php");
    exit;
}
require_once __DIR__ . '/flash.php';

function nav_active($page) {
    return basename($_SERVER['PHP_SELF']) === $page ? 'active' : '';
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin - Smart Library</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="../admin/dashboard.php">Smart Library (Admin)</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="adminNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php echo nav_active('dashboard.php'); ?>" href="../admin/dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo nav_active('add_book.php'); ?>" href="../admin/add_book.php">Add Book</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo nav_active('view_books.php'); ?>" href="../admin/view_books.php">Manage Books</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo nav_active('view_requests.php'); ?>" href="../admin/view_requests.php">Requests</a>
        </li>
      </ul>
      <a href="../admin/logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
  </div>
</nav>
<div class="container mb-5">
<?php show_flash(); ?>
