<?php
// /includes/flash.php
// Simple session-based flash message helper.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function set_flash($type, $msg) {
    $_SESSION['flash'] = ['type'=>$type, 'msg'=>$msg];
}

function show_flash() {
    if (!empty($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type']; // success, danger, warning, info
        $msg  = $_SESSION['flash']['msg'];
        echo "<div class='alert alert-$type alert-dismissible fade show' role='alert'>"
           . htmlspecialchars($msg)
           . "<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
        unset($_SESSION['flash']);
    }
}
?>
