<?php
include '../includes/client_header.php';
include '../backend/db.php';

$student_id = $_SESSION['student_id'];

$sql = "SELECT r.request_id, r.student_name, r.student_id, r.status, r.request_date,
               b.title, b.author
        FROM book_requests r
        JOIN book b ON r.book_id = b.book_id
        WHERE r.student_id = ?
        ORDER BY r.request_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<h2 class="mb-4">My Book Requests</h2>

<div class="table-responsive">
<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>Book Title</th>
      <th>Author</th>
      <th>Status</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><?= htmlspecialchars($row['author']) ?></td>
          <td>
            <?php
            $status = $row['status'];
            $badgeClass = $status === 'Approved' ? 'success' : ($status === 'Rejected' ? 'danger' : 'warning');
            ?>
            <span class="badge bg-<?= $badgeClass ?>"><?= $status ?></span>
          </td>
          <td><?= $row['request_date'] ?></td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="4" class="text-center">No requests found.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</div>
<?php
$stmt->close();
$conn->close();
?>
<?php include '../includes/footer.php'; ?>
