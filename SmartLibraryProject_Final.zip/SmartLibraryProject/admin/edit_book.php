<?php
include '../includes/admin_header.php';
include '../backend/db.php';

if (!isset($_GET['id'])) {
    die("No book ID provided.");
}
$id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM book WHERE book_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>
<h2 class="mb-4">Edit Book</h2>
<form action="../backend/update_book.php" method="POST" class="border p-4 bg-white rounded shadow-sm">
  <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">
  <div class="mb-3">
    <label>Title</label>
    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>" required>
  </div>
  <div class="mb-3">
    <label>Author</label>
    <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($book['author']) ?>" required>
  </div>
  <div class="mb-3">
    <label>ISBN</label>
    <input type="text" name="isbn" class="form-control" value="<?= htmlspecialchars($book['isbn']) ?>" required>
  </div>
  <div class="mb-3">
    <label>Category</label>
    <input type="text" name="category" class="form-control" value="<?= htmlspecialchars($book['category']) ?>">
  </div>
  <div class="mb-3">
    <label>Quantity</label>
    <input type="number" min="0" name="quantity" class="form-control" value="<?= $book['quantity'] ?>" required>
  </div>
  <button type="submit" class="btn btn-success">Save Changes</button>
  <a href="view_books.php" class="btn btn-secondary">Cancel</a>
</form>
<?php include '../includes/footer.php'; ?>
