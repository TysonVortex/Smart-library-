<?php
include '../includes/admin_header.php';
include '../backend/db.php';

$sql = "SELECT r.request_id, r.student_name, r.student_id, r.status, r.request_date,
               b.title, b.author
        FROM book_requests r
        JOIN book b ON r.book_id = b.book_id
        ORDER BY r.request_date DESC";
$result = $conn->query($sql);
?>
<h2 class="mb-4">Book Issue Requests</h2>

<div class="table-responsive">
<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>Req ID</th>
      <th>Student</th>
      <th>Student ID</th>
      <th>Book Title</th>
      <th>Author</th>
      <th>Status</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['request_id'] ?></td>
          <td><?= htmlspecialchars($row['student_name']) ?></td>
          <td><?= htmlspecialchars($row['student_id']) ?></td>
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><?= htmlspecialchars($row['author']) ?></td>
          <td>
            <?php
            $status = $row['status'];
            $badgeClass = $status === 'Approved' ? 'success' : ($status === 'Rejected' ? 'danger' : 'warning');
            ?>
            <span class="badge bg-<?= $badgeClass ?>"><?= $status ?></span>
          </td>
          <td><?= $row['request_date'] ?></td>
          <td>
            <?php if ($status === 'Pending'): ?>
              <a href="../backend/handle_request_update.php?id=<?= $row['request_id'] ?>&action=approve" class="btn btn-sm btn-success">Approve</a>
              <a href="../backend/handle_request_update.php?id=<?= $row['request_id'] ?>&action=reject" class="btn btn-sm btn-danger">Reject</a>
            <?php else: ?>
              <em>—</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="8" class="text-center">No book requests found.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</div>
<?php
$conn->close();
?>
<?php include '../includes/footer.php'; ?>
