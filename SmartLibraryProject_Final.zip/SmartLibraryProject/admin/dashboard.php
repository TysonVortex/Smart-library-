<?php include '../includes/admin_header.php'; ?>
<h2>Welcome, Admin!</h2>
<p class="lead">Use the shortcuts below to manage your library.</p>
<div class="d-flex gap-2 flex-wrap mt-4">
  <a href="add_book.php" class="btn btn-primary btn-lg">Add Book</a>
  <a href="view_books.php" class="btn btn-secondary btn-lg">Manage Books</a>
  <a href="view_requests.php" class="btn btn-warning btn-lg text-white">Manage Requests</a>
</div>
<?php include '../includes/footer.php'; ?>
