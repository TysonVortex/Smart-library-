<?php
include '../includes/admin_header.php';
include '../backend/db.php';

$search = '';
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM book WHERE is_deleted = FALSE AND 
            (title LIKE ? OR author LIKE ? OR isbn LIKE ?)
            LIMIT ?, ?";
    $searchParam = "%$search%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $searchParam, $searchParam, $searchParam, $offset, $limit);
} else {
    $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM book WHERE is_deleted = FALSE LIMIT ?, ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $offset, $limit);
}
$stmt->execute();
$result = $stmt->get_result();

$totalRes = $conn->query("SELECT FOUND_ROWS() as total")->fetch_assoc();
$total = $totalRes['total'];
$totalPages = ceil($total / $limit);
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<h2 class="mb-4">Manage Books</h2>

<form method="GET" class="mb-3 d-flex">
  <input type="text" name="search" placeholder="Search by title, author, ISBN" value="<?= htmlspecialchars($search) ?>" class="form-control me-2" />
  <button type="submit" class="btn btn-secondary">Search</button>
</form>

<div class="table-responsive">
<table class="table table-bordered table-striped align-middle">
  <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Author</th>
      <th>ISBN</th>
      <th>Category</th>
      <th>Quantity</th>
      <th>Created</th>
      <th>Updated</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr class="<?= $row['quantity']==0 ? 'table-danger' : '' ?>">
          <td><?= $row['book_id'] ?></td>
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><?= htmlspecialchars($row['author']) ?></td>
          <td><?= htmlspecialchars($row['isbn']) ?></td>
          <td><?= htmlspecialchars($row['category']) ?></td>
          <td>
            <?= $row['quantity'] ?>
            <?php if ($row['quantity']==0): ?><span class="badge bg-danger">Out of Stock</span><?php endif; ?>
          </td>
          <td><?= $row['created_at'] ?></td>
          <td><?= $row['updated_at'] ?></td>
          <td class="d-flex gap-1">
            <a href="edit_book.php?id=<?= $row['book_id'] ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></a>
            <a href="../backend/delete_book.php?id=<?= $row['book_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this book?');"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="9" class="text-center">No books found.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</div>

<!-- Pagination -->
<nav>
  <ul class="pagination">
    <?php for($i=1;$i<=$totalPages;$i++): ?>
      <li class="page-item <?= ($i==$page)?'active':'' ?>">
        <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>

<?php
$stmt->close();
$conn->close();
?>
<?php include '../includes/footer.php'; ?>
