<?php include '../includes/admin_header.php'; ?>
<h2 class="mb-4">Add New Book</h2>
<form action="../backend/insert_book.php" method="POST" class="border p-4 bg-white rounded shadow-sm">
  <div class="mb-3">
    <label>Title</label>
    <input type="text" name="title" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Author</label>
    <input type="text" name="author" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>ISBN</label>
    <input type="text" name="isbn" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Category</label>
    <input type="text" name="category" class="form-control">
  </div>
  <div class="mb-3">
    <label>Quantity</label>
    <input type="number" name="quantity" min="0" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-success">Add Book</button>
  <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
</form>
<?php include '../includes/footer.php'; ?>
